import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { featchtodo } from './redux/ApiSlice';

function App() {
    const dispatch = useDispatch();
    const state = useSelector((state) => state);
    console.log('state', state)

    if (state.todo.isLoading) {
        return <h1>loading.............</h1>;
    }
    return (
        <div>
            <button onClick={(e) => dispatch(featchtodo())}>todo</button>
            {
               
                state.todo.data && state.todo.data.map((e) =>
                    < div key={e.id}>
                    <img src={e.image} alt={e.title} height="200px"width="200px" />
                    <h2><li>{e.title}</li></h2>
                    <h3>price={e.price}</h3>
                    <h4>{e.category}</h4>
                    <button>avi</button>

                    </div>
                
            )}
        </div>
    );
}

export default App
