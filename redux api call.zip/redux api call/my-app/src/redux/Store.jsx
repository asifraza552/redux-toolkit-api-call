import { configureStore } from '@reduxjs/toolkit'
import todoReducer from './ApiSlice'

export const store = configureStore({
  reducer: {
    todo:todoReducer,

  },
})