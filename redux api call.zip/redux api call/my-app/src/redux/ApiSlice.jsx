import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'

// action
export const featchtodo = createAsyncThunk(' featchtodo', async () => {
    // const responce = await fetch('https://jsonplaceholder.typicode.com/todos');
    const responce = await fetch('https://fakestoreapi.com/products');
    return responce.json();
})
export const todoSlice = createSlice({
    name: 'todo',
    initialState: {
        isLoading: false,
        data: null,
        iserror: false,
    },

    extraReducers: (builder) => {
        builder.addCase(featchtodo.pending, (state, action) => {
            state.isLoading = true;
        });
        builder.addCase(featchtodo.fulfilled, (state, action) => {
            state.isLoading = false;
            state.data = action.payload;
        });
        builder.addCase(featchtodo.rejected, (state, action) => {
            console.log("errorrrrrrrrrrrr", action.payload)
            state.iserror = true;
        });
    },

});

// Action creators are generated for each case reducer function
export const { } = todoSlice.actions

export default todoSlice.reducer